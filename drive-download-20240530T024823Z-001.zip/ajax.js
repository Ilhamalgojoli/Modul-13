function buatPost() {
    
}

function ambilPost() {
    
}

function hapusPost(id) {
    
}

function likePost(id) {
    
}

function unlikePost(id) {
    
}
