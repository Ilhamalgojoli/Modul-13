<?php  
include 'connection.php';

session_start();
if (!isset($_SESSION['id_user'])) {
    header('Location: login.php');
    exit();
}

$id_user = $_SESSION['id_user'];

$sql = "isi query disini";
$result = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    $postContent = htmlspecialchars($row['post'], ENT_QUOTES, 'UTF-8');
    $postId = $row['id_post'];
    $fullname = htmlspecialchars($row['fullname'], ENT_QUOTES, 'UTF-8');
    $createdAt = $row['created_at'];
    $postOwnerId = $row['post_owner_id'];

   // cek apakah current user = pemilik postingan?
    

    echo "
    <div class='box' id='content-container'>
        <div class='row'>
            <div class='col-md-1'></div>
            <div class='col-md-11' style='padding-left:5px;'>
                <p class='text-muted' id='post-text'>$postContent</p>
                <p class='text-muted'>Posted by: $fullname, $createdAt</p>
                ";

    // Display the delete button only if the current user is the owner of the post
    
    echo "</div></div></div>";
}
?>
